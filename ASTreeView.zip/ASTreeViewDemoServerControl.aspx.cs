using System;

namespace Goldtect.ASTreeViewDemo
{
	public partial class ASTreeViewDemoServerControl : System.Web.UI.Page
	{
		protected void Page_Load( object sender, EventArgs e )
		{

		}
	}
}
